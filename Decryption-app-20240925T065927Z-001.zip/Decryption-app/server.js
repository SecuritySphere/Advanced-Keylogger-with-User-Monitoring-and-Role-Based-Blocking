const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/upload', upload.fields([{ name: 'encryptedFile' }, { name: 'keyFile' }]), (req, res) => {
  const encryptedFilePath = req.files['encryptedFile'][0].path;
  const keyFilePath = req.files['keyFile'][0].path;

  exec(`python3 decrypt.py ${keyFilePath} ${encryptedFilePath}`, (error, stdout, stderr) => {
    if (error) {
      res.send({ success: false, error: stderr });
      return;
    }
    res.send({ success: true, data: stdout });
  });
});

app.post('/save', (req, res) => {
  const { data, fileName } = req.body;
  const filePath = path.join(__dirname, 'uploads', fileName);
  fs.writeFileSync(filePath, data, 'utf8');
  res.send({ success: true, message: 'File saved successfully' });
});

app.post('/modifyFile', (req, res) => {
  const { fileName, fileContent } = req.body;
  const filePath = path.join(__dirname, 'uploads', fileName);

  // Log the values to ensure they are correct
  console.log(`Saving file: ${filePath}`);
  console.log(`File content: ${fileContent}`);

  // Save the file content
  fs.writeFile(filePath, fileContent, (err) => {
    if (err) {
      console.error(`Error saving file: ${err.message}`);
      res.json({ success: false, error: err.message });
    } else {
      res.json({ success: true, message: 'File saved successfully' });
    }
  });
});
