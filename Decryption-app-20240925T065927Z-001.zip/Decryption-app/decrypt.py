import sys
from cryptography.fernet import Fernet

def load_encryption_key(filename):
    with open(filename, 'rb') as f:
        return f.read()

def decrypt_data(encrypted_data, key):
    cipher = Fernet(key)
    return cipher.decrypt(encrypted_data).decode()

if __name__ == "__main__":
    key_file = sys.argv[1]
    encrypted_file = sys.argv[2]

    key = load_encryption_key(key_file)
    with open(encrypted_file, 'rb') as f:
        encrypted_data = f.read()

    decrypted_data = decrypt_data(encrypted_data, key)
    print(decrypted_data)
